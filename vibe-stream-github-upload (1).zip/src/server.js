require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { pool } = require('./db');
const paymentRoutes = require('./routes/payments');

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.APP_BASE_URL || 'http://localhost:3000' }));

// Keep raw body for webhook signature verification; do not parse JSON first on this route.
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), paymentRoutes.webhook);
app.use(express.json({ limit: '100kb' }));

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch {
    res.status(503).json({ status: 'degraded', database: 'unavailable' });
  }
});

app.use('/api/payments', paymentRoutes.router);

app.use((err, _req, res, _next) => {
  console.error('Request failed:', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`VIBE STREAM API listening on port ${port}`));
