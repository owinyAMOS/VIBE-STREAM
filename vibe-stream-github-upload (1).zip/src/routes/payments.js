const express = require('express');
const crypto = require('crypto');
const { pool } = require('../db');

const router = express.Router();
const price = Number(process.env.SUBSCRIPTION_PRICE_UGX || 5000);
const flutterwaveBase = process.env.FLUTTERWAVE_BASE_URL || 'https://api.flutterwave.com/v3';

// This endpoint only creates a payment initialization request.
// Configure credentials and validate the request/user identity before production use.
router.post('/initialize', async (req, res) => {
  const { email, phoneNumber, userId } = req.body || {};
  if (!email || !phoneNumber || !userId) {
    return res.status(400).json({ error: 'email, phoneNumber, and userId are required' });
  }
  if (!process.env.FLUTTERWAVE_SECRET_KEY ||
      process.env.FLUTTERWAVE_SECRET_KEY.includes('REPLACE_ME')) {
    return res.status(503).json({ error: 'Payment provider credentials are not configured' });
  }

  const txRef = `vibe_${crypto.randomUUID()}`;
  try {
    const response = await fetch(`${flutterwaveBase}/payments`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        tx_ref: txRef,
        amount: price,
        currency: 'UGX',
        redirect_url: `${process.env.APP_BASE_URL}/payment-result`,
        customer: { email, phonenumber: phoneNumber },
        customizations: { title: 'VIBE STREAM', description: 'Monthly subscription' },
        meta: { userId }
      })
    });
    const result = await response.json();
    if (!response.ok || result.status !== 'success' || !result.data?.link) {
      console.error('Flutterwave initialization failed:', result.message || response.status);
      return res.status(502).json({ error: 'Could not initialize payment' });
    }

    await pool.query(
      `INSERT INTO payments (user_id, tx_ref, amount, currency, status)
       VALUES ($1, $2, $3, 'UGX', 'pending')`,
      [userId, txRef, price]
    );
    return res.status(200).json({ paymentUrl: result.data.link, txRef });
  } catch (err) {
    console.error('Payment initialization error:', err.message);
    return res.status(500).json({ error: 'Payment initialization failed' });
  }
});

// Verify successful transactions server-to-server before granting access.
// Webhook notifications are hints only; never trust the browser redirect alone.
async function verifyTransaction(transactionId) {
  if (!process.env.FLUTTERWAVE_SECRET_KEY) throw new Error('Payment key not configured');
  const response = await fetch(`${flutterwaveBase}/transactions/${encodeURIComponent(transactionId)}/verify`, {
    headers: { Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}` }
  });
  const body = await response.json();
  if (!response.ok || body.status !== 'success') throw new Error('Provider verification failed');
  return body.data;
}

async function webhook(req, res) {
  const secretHash = process.env.FLUTTERWAVE_SECRET_HASH;
  const signature = req.get('verif-hash');
  if (!secretHash || !signature || signature !== secretHash) {
    return res.status(401).send('Invalid webhook signature');
  }

  let event;
  try {
    event = JSON.parse(req.body.toString('utf8'));
  } catch {
    return res.status(400).send('Invalid JSON');
  }

  if (event?.event !== 'charge.completed' || !event?.data?.id) {
    return res.status(200).send('Event ignored');
  }

  try {
    const verified = await verifyTransaction(event.data.id);
    if (verified.status !== 'successful' ||
        verified.currency !== 'UGX' ||
        Number(verified.amount) < price) {
      return res.status(200).send('Payment not eligible for subscription');
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const payment = await client.query(
        `SELECT user_id, tx_ref, status FROM payments
         WHERE tx_ref = $1 FOR UPDATE`,
        [verified.tx_ref]
      );
      if (payment.rowCount === 0) {
        await client.query('ROLLBACK');
        return res.status(200).send('Unknown transaction reference');
      }
      if (payment.rows[0].status !== 'successful') {
        await client.query(
          `UPDATE payments SET status = 'successful', provider_transaction_id = $1
           WHERE tx_ref = $2`,
          [String(verified.id), verified.tx_ref]
        );
        await client.query(
          `INSERT INTO subscriptions (user_id, starts_at, expires_at, status)
           VALUES ($1, NOW(), NOW() + INTERVAL '30 days', 'active')
           ON CONFLICT (user_id) DO UPDATE
           SET starts_at = GREATEST(subscriptions.expires_at, NOW()),
               expires_at = GREATEST(subscriptions.expires_at, NOW()) + INTERVAL '30 days',
               status = 'active'`,
          [payment.rows[0].user_id]
        );
      }
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
    return res.status(200).send('Webhook processed');
  } catch (err) {
    console.error('Webhook processing error:', err.message);
    return res.status(500).send('Webhook processing failed');
  }
}

router.get('/status/:userId', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT status, starts_at, expires_at
       FROM subscriptions WHERE user_id = $1 AND expires_at > NOW()`,
      [req.params.userId]
    );
    res.json({ active: result.rowCount > 0, subscription: result.rows[0] || null });
  } catch (err) {
    console.error('Subscription lookup failed:', err.message);
    res.status(500).json({ error: 'Could not check subscription' });
  }
});

module.exports = { router, webhook };
