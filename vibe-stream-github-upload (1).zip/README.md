# VIBE STREAM subscription backend

Node.js + Express + PostgreSQL starter for a UGX 5,000 monthly subscription.

## Important status

This is a **starter project**, not a production-ready payment service. Flutterwave credentials, database configuration, account/user authentication, provider account setup, and end-to-end testing are still required. Do not advertise payments as working until test transactions and webhook verification have been completed.

## Requirements

- Node.js 20+
- PostgreSQL database
- Flutterwave account and API credentials

## Run locally

1. Copy `.env.example` to `.env`.
2. Fill in local PostgreSQL connection details and Flutterwave test credentials.
3. Install dependencies: `npm install`
4. Create the database tables using your PostgreSQL client and `db/schema.sql`.
5. Start the server: `npm run dev`
6. Check `http://localhost:3000/health`.

## API routes

- `GET /health` — service/database health check.
- `POST /api/payments/initialize` — accepts `email`, `phoneNumber`, and `userId`.
- `POST /api/payments/webhook` — provider webhook receiver.
- `GET /api/payments/status/:userId` — subscription status lookup.

## Before production

- Implement real authentication and derive `userId` from the authenticated session; never trust a client-supplied user ID.
- Configure a verified HTTPS webhook URL in Flutterwave.
- Confirm Flutterwave's current webhook signature scheme and payment verification response for your account before going live.
- Add rate limiting, request validation, logging/monitoring, idempotency tests, and automated tests.
- Ensure your production database supports TLS and backups.
- Confirm the chosen payment flow supports your required Uganda Mobile Money options (MTN and Airtel) in your Flutterwave account.
- Run an expiry job if you need to mark old records as `expired`; access checks should always also require `expires_at > NOW()`.

## Secrets

Never commit `.env`, real API keys, webhook secrets, or database passwords. Use your hosting provider's environment-variable settings.
